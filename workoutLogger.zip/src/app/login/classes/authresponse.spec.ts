import { Authresponse } from './authresponse';

describe('Authresponse', () => {
  it('should create an instance', () => {
    expect(new Authresponse()).toBeTruthy();
  });
});
