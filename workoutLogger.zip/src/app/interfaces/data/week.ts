export interface WEEK{
	label:string;	
	time:number;
}