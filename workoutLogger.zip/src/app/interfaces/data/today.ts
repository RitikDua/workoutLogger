export interface TODAY{
	exerciseName:string;
	time:number;
}