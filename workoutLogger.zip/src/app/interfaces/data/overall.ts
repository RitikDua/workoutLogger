export interface OVERALL{
	[key:string]:number;
}
//key is label as date
//value is time 