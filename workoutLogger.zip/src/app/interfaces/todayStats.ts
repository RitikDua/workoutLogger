import {EXERCISE} from './exercise';

export interface OneDayStats{
	[key:string]:EXERCISE;
}