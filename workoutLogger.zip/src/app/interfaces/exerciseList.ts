export interface ExerciseList {
	[key:string]:string[];
}