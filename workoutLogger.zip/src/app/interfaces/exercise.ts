export interface EXERCISE{
	// name:string;
	sets?:number;
	reps?:number;
	hrs?:number;
	mins?:number;
}