import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subprofile',
  templateUrl: './subprofile.component.html',
  styleUrls: ['./subprofile.component.css']
})
export class SubprofileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
