export const quotes:string[]=[

]

export const quotesAuthor:string[]=[

]

