const mongoose = require('mongoose');
const {Stat} =require("./stat");
const clientSchema = new mongoose.Schema({
  
  username: {
    type: String,
    unique:true,
    required:true
  },
  exerciseList:[{
  	index:String,//Day of the week
  	exercises:[String]
  }],
  stat:[{type: mongoose.Schema.Types.ObjectId, ref:'Stat'}]

});

exports.Client=mongoose.model('Client', clientSchema);