

const mongoose = require('mongoose');


const todaySchema = new mongoose.Schema({
  userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    },
  index:{
  type:String,//exercise Name
  },
  exercise:{
  	sets:Number,
  	reps:Number,
  	hrs:Number,
  	mins:Number
  }
  
});
const statSchema = new mongoose.Schema({
  userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    },
  date:String,
  weight:Number,
  height:Number,
  todayStat:[{type: mongoose.Schema.Types.ObjectId, ref:'todayStat'}]
});

exports.Stat=mongoose.model("Stat",statSchema);
exports.TodayStat=mongoose.model("TodayStat",todaySchema);
