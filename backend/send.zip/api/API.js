const router=require("express").Router();
const mongoose=require("mongoose");
const Client=require("../models/client/client");
const Stat=require("../models/client/stat");
const TodayStat=require("../models/client/stat");

//add exercise List
router.post("/new",(req,res,next)=>{
	const client=new Client(req.body);
	Client.findOne({username:req.body.username},(err,savedUser)=>{
		if(err) return err;
		if(savedUser) res.json({
			username:savedUser.username,
			_id:savedUser._id
			})
		else{
			user.save((err,user)=>{
				if(err) return next(err);
				res.json({
					username:user.username,
					_id:user._id
				})
			})
		}
		}
	)
})
router.get("/fun",(req,res)=>{
	res.send("e");
})

module.exports=router;